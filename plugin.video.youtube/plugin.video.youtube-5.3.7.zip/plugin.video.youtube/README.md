Do not use this repo to update as I will not be applying any new updates.

I do not have the abilities that i need to fully manage this repo.

Please start using

https://github.com/jdf76/plugin.video.youtube

Thank you,
Jeff (jdf76)
